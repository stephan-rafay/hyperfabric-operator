# Hyperfabric Operator Helm Chart

Deploys the Hyperfabric Kubernetes Operator, which reconciles `HfController` and
`HfNodeMembership` custom resources against the Cisco Hyperfabric API.

## Namespaces (standard layout)

| Namespace | Role |
| --- | --- |
| `hf-operator` | Operator **Deployment** and Helm release (use `helm install -n hf-operator ...`) |
| `hyperfabric-system` | `HfController` / `HfNodeMembership` **CRs** created by Rafay / paas-controller (chart can create this namespace) |

The chart **does not** template a `Namespace` for the release namespace. That
avoids Helm "invalid ownership metadata" when `hf-operator` already exists.
Instead, create the release namespace with Helm’s client flag:

- **New cluster / NS missing:** `helm install ... -n hf-operator --create-namespace`  
  Helm 3+ applies `meta.helm.sh/release-name` and `meta.helm.sh/release-namespace` on the
  created namespace and `app.kubernetes.io/managed-by: Helm`.

- **NS `hf-operator` already exists, no Helm labels:** You do **not** need to
  patch the namespace to install the chart **as long as the chart does not
  own a `Namespace` manifest for that name** (this chart does not). A normal
  `helm install -n hf-operator` will place resources into the existing
  namespace. (Only add `meta.helm.sh/*` if you later add a `Namespace` resource
  to the same release, or if you use tools that require them.)

- **To adopt a pre-existing namespace into a release** (advanced): use
  `helm install --adopt` / `helm upgrade --install --adopt` (Helm 3.14+), or
  label/annotate the namespace to match the release. Not required for the
  default layout above.

`hyperfabric-system` is created as a `Namespace` resource **by this release**
when `crNamespace.create=true` (default). If that namespace **already** exists
without Helm metadata, the install can fail; use
`--set crNamespace.create=false` and create/manage it out-of-band, or use
`--adopt` to bring it under this release (Helm 3.14+).

## Prerequisites

- Kubernetes 1.27+
- Helm 3.x
- For sharded mode: cert-manager (to inject TLS certs for the admission webhook)

## Install

### Single operator (default)

One operator instance handles all CRs. **Install into `hf-operator`** and create
`hyperfabric-system` for CRs:

```bash
helm install hf-operator ./hf-operator/charts/hyperfabric-operator \
  -n hf-operator \
  --create-namespace \
  --set image.tag=<TAG>
```

`--create-namespace` is required on first install if `hf-operator` does not
exist yet. If the namespace **already** exists, omit that flag.

Disable only the `hyperfabric-system` template if the namespace is managed
elsewhere (GitOps, shared cluster, second shard release, etc.):

```bash
--set crNamespace.create=false
```

Override the default CR namespace name:

```bash
--set crNamespace.name=hyperfabric-dev
```

Allow installing into a namespace other than `hf-operator` (breaks the default
guard used by your platform):

```bash
helm install my-op ./hf-operator/charts/hyperfabric-operator \
  -n my-custom-ns --create-namespace \
  --set release.enforceNamespace=false
```

### Active-active sharded (multiple operators)

Each operator instance owns a slice of CRs based on a shard label
(`hyperfabric.rafay.dev/shard`). A mutating admission webhook automatically
assigns the shard label when CRs are created.

The example file disables `release.enforceNamespace` so you can choose a
namespace (e.g. install all shards in `hf-operator` with different release
names, or use another namespace).

```bash
helm install hf-shard-0 ./hf-operator/charts/hyperfabric-operator \
  -n hf-operator -f examples/sharded-values.yaml \
  --set image.tag=<TAG> \
  --set sharding.enabled=true \
  --set sharding.shardId=0 \
  --set webhook.enabled=true \
  --set crNamespace.create=true

# Shards 1–3: set crNamespace.create=false after hyperfabric-system exists
helm install hf-shard-1 ./hf-operator/charts/hyperfabric-operator \
  -n hf-operator -f examples/sharded-values.yaml \
  --set image.tag=<TAG> \
  --set sharding.enabled=true \
  --set sharding.shardId=1 \
  --set crNamespace.create=false
```

(Only one release should own the `Namespace/hyperfabric-system` resource;
others should use `crNamespace.create=false` once it exists.)

## Uninstall

```bash
helm uninstall hf-operator -n hf-operator
```

For sharded deployments, uninstall each release. Optionally delete namespaces
if no longer needed: `hyperfabric-system` (CRs) and `hf-operator` (operator)
— coordinate with workloads.

## Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Operator pod replicas (per shard release) | `1` |
| `image.repository` | Operator image repository | `registry.dev.rafay-edge.net/dev/hyperfabric-operator` |
| `image.tag` | Operator image tag | `latest` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `release.enforceNamespace` | Fail install unless `-n` matches `release.requireNamespace` | `true` |
| `release.requireNamespace` | Required release namespace (when enforce is on) | `hf-operator` |
| `crNamespace.create` | Create `Namespace` for Rafay/CR placement | `true` |
| `crNamespace.name` | Namespace name for Hf* CRs | `hyperfabric-system` |
| `crNamespace.extraLabels` | Extra labels on the CR namespace | `{}` |
| `crNamespace.extraAnnotations` | Extra annotations on the CR namespace | `{}` |
| `operator.leaderElect` | Enable leader election | `true` |
| `operator.maxConcurrentReconciles` | Max concurrent reconciles per controller | `4` |
| `operator.metricsBindAddress` | Metrics endpoint bind address | `:8080` |
| `operator.healthProbeBindAddress` | Health probe bind address | `:8081` |
| `operator.enablePprof` | Enable pprof on `:6060` | `false` |
| `sharding.enabled` | Enable shard-based active-active mode | `false` |
| `sharding.shardId` | Shard ID for this release (`0`..`shardCount-1`) | `""` (all objects) |
| `sharding.shardCount` | Total number of logical shards | `4` |
| `webhook.enabled` | Deploy the shard-assignment mutating webhook | `false` |
| `webhook.port` | Webhook server port | `9443` |
| `webhook.replicas` | Webhook pod replicas | `2` |
| `webhook.resources` | Webhook pod resource requests/limits | see `values.yaml` |
| `resources` | Operator pod resource requests/limits | see `values.yaml` |
| `serviceAccount.create` | Create a ServiceAccount | `true` |
| `serviceAccount.name` | ServiceAccount name | `hyperfabric-operator` |

### Low-resource / memory-constrained clusters

If the operator pod stays **Pending** with `Insufficient memory` (or CPU), use the default sizing in `values.yaml` or override (see `examples/low-resources-values.yaml`):

```bash
helm upgrade --install hf-operator ./hf-operator/charts/hyperfabric-operator \
  -n hf-operator -f examples/low-resources-values.yaml \
  --set image.tag=<TAG>
```

## How sharding works

1. **Webhook** — a `MutatingWebhookConfiguration` intercepts `CREATE` requests
   for `HfController` and `HfNodeMembership`. It computes a deterministic shard
   ID (FNV-1a hash of kind/namespace/name mod `shardCount`) and injects the
   label `hyperfabric.rafay.dev/shard=<N>`.

2. **Operator** — each operator instance runs with `--shard=<N>`. Its
   controller-runtime cache is restricted to objects matching that shard label,
   so each instance only watches and reconciles its own slice.

3. **Single mode** — when `sharding.enabled=false` (default), no webhook is
   deployed and the operator runs with `--shard=""`, which means it reconciles
   all objects regardless of labels.
