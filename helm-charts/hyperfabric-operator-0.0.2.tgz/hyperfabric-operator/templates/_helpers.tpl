{{- define "hyperfabric-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "hyperfabric-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "hyperfabric-operator.labels" -}}
helm.sh/chart: {{ include "hyperfabric-operator.name" . }}-{{ .Chart.Version }}
{{ include "hyperfabric-operator.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "hyperfabric-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "hyperfabric-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
